//ANIMACION DE LA BIENVENIDA
//  setTimeout(() => {
//       document.querySelector("#bienvenida").style.opacity = 0; 
//  }, 3000); // muestra la animacion por 4 segundos
